﻿namespace Session2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            #region Operators


            // Braces                       ()
            // Prefix                       ++variable , --variable
            // Arithmatic Operations        *,/,%,+,-
            // Comparison Operations        >,<,>=,<=,==,!=
            // Logical Operations           && , || , Bitwise (& , |)
            // Assignment Operations        = , += , -= , /= , *= , %=
            // Postfix                      Variable++ , Variable--


            //var x = 1; // 2
            //var y = 1 + (++x / 2);
            //Console.WriteLine(y);

            //var x = 4; // 5
            //var y = 1 + (x++ / 2); // 3
            //Console.WriteLine(y);
            //Console.WriteLine(x);


            //int x = 10;
            //int y = 20;
            //int z = 30;

            //Console.WriteLine(x != y);


            // var x = (a > b) && (b < c);
            // 

            // Logical Operators

            // And &&

            // True && True ====> True
            // True && False ====> False
            // False && True ====> False
            // False && False ====> False

            // Or ||

            // True && True ====> True
            // True && False ====> True
            // False && True ====> True
            // False && False ====> False


            //var w = x > z && z > x;
            //Console.WriteLine(w);



            //var x = 10;
            //x += 5; // x = x + 5 ;
            //Console.WriteLine(x);



            //int x = 1; // 2
            //int y = 2;
            //int z = 3;
            //int w = (x++ + 2) * ((z += 1) / (++x + 1) + (y += 2));

            //Console.WriteLine(w);

            #endregion

            #region Statements

            // Conditional Statements الجمل الشرطيه
            // IF , IF..Else , IF..Else IF (Cascading IF , Neasted IF)

            //int x = 200;

            //if (x > 100)
            //{
            //    Console.WriteLine("Greater Than");
            //}
            //else
            //{
            //    Console.WriteLine("Less Than");
            //}

            // Silver ==> 15%
            // Gold ===> 35%
            // VIP  ===> 50%

            //Console.Write("Please Enter Your Membership : ");
            //var Membership = Console.ReadLine();

            //if (Membership == "silver")
            //{
            //    Console.WriteLine("Discont 15%");
            //}
            //else if (Membership == "gold")
            //{
            //    Console.WriteLine("Discount 35%");
            //}
            //else if (Membership == "vip")
            //{
            //    Console.WriteLine("Discount 50%");
            //}
            //else
            //{
            //    Console.WriteLine("Not Allow, Enter Valid Value");
            //}



            // Enter Your Degree : 76

            // 0 - 49 ==> F
            // 50 - 69 ==> D
            // 70 - 79 ==> C
            // 80 - 89 ==> B
            // 90 - 100 ==> A
            // Else ==> N/A , Enter Valid Value


            // Your Grade Is : C



            //Console.Write("Please Enter Your Degree : ");
            //int degree = int.Parse(Console.ReadLine());

            //if (degree >= 0 && degree <= 49)
            //    Console.WriteLine("F");
            //else if (degree >= 50 && degree <= 69)
            //    Console.WriteLine("D");
            //else if (degree >= 70 && degree <= 79)
            //    Console.WriteLine("C");
            //else if (degree >= 80 && degree <= 89)
            //    Console.WriteLine("B");
            //else if (degree >= 90 && degree <= 100)
            //    Console.WriteLine("A");
            //else
            //    Console.WriteLine("Not Allow, Enter Valid Value");


            // Switch ... Case

            //int x = 3;

            //switch (x)
            //{
            //    case 10:
            //        Console.WriteLine("Welcome 10");
            //        break;

            //    case 3:
            //        Console.WriteLine("Welcome 3");
            //        break;

            //    case 20:
            //        Console.WriteLine("Welcome 20");
            //        break;

            //    default:
            //        Console.WriteLine("N/A");
            //        break;
            //}

            //int x = 5;

            //switch (x)
            //{
            //    case 1:
            //    case 2:
            //        Console.WriteLine("Welcome");
            //        break;

            //    case 3:
            //        Console.WriteLine("Welcome 3");
            //        break;

            //    default:
            //        Console.WriteLine("N/A");
            //        break;
            //}


            //Console.Write("Plz Enter Value 1 : ");
            //int value_1 = int.Parse(Console.ReadLine());

            //Console.Write("Plz Enter Operator : ");
            //char op = char.Parse(Console.ReadLine()); // + , - , / , *

            //Console.Write("Plz Enter Value 2 : ");
            //int value_2 = int.Parse(Console.ReadLine());

            //switch (op)
            //{
            //    case '+':
            //        Console.WriteLine($"The Sum : {value_1 + value_2}");
            //        break;

            //    case '-':
            //        Console.WriteLine($"The Subtraction : {value_1 - value_2}");
            //        break;

            //    case '*':
            //        Console.WriteLine($"The Multiplication : {value_1 * value_2}");
            //        break;

            //    case '/':
            //        if (value_2 != 0)
            //            Console.WriteLine($"The Division : {value_1 / value_2}");
            //        else
            //            Console.WriteLine("Can not divid By Zero");
            //        break;

            //    default:
            //        Console.WriteLine("N/A");
            //        break;
            //}



            // Ternary Operator ?"IF" :"Else"

            //int age = 25;

            //if (age < 18)
            //    Console.WriteLine("Denied Access");
            //else
            //    Console.WriteLine("Allow Access");


            //int age = 25;
            //int gender = 1;
            //var result = (gender == 1) ? "Male" : (gender == 2) ? "Female" : "N/A";
            //Console.WriteLine(result);



            // Iteration Statements الجمل التكرارايه 
            // For 
            // While
            // Do..While
            // ForEach

            //for (int i = 1; i <= 10; i++)
            //{
            //    Console.WriteLine(i);
            //}

            //for (int i = 100; i >= 0; i -= 2)
            //{
            //    Console.WriteLine(i);
            //}


            //for (int i = 100; i >= 0; i--)
            //{
            //    if (i % 2 == 0)
            //        Console.WriteLine(i);
            //}

            //int i = 1;
            //for (; i <= 10;)
            //{
            //    Console.WriteLine(i);
            //    i++;
            //}

            // intial
            //while (condition)
            //{
            //    code;
            //    counter
            //}

            //int x = 1;
            //while (x >= 10)
            //{
            //    Console.WriteLine(x);
            //    x++;
            //}


            // For   ,   While

            // initial value
            // condition
            // code 
            // counter



            // do  ... while

            // initial
            // code
            // counter
            // condition


            //int x = 1;
            //do
            //{
            //    Console.WriteLine(x);
            //    x++;

            //} while (x <= 10);


            //char result;
            //do
            //{
            //    Console.Write("First N : ");
            //    int Fn = int.Parse(Console.ReadLine());

            //    Console.Write("Second N : ");
            //    int Sn = int.Parse(Console.ReadLine());

            //    Console.WriteLine($"The Result : {Fn / Sn}");

            //    Console.Write("Are you want do this again (y,n) : ");
            //    result = char.Parse(Console.ReadLine());

            //} while (result == 'y' || result == 'Y');


            // Cascading For 


            // Table 1
            // =========
            // 1 * 1 = 1
            // 1 * 2 = 2
            // 1 * 3 = 3
            // ===============================
            // Table 2
            // ========
            // 2 * 1 = 2
            // 2 * 2 = 4
            // 2 * 3 = 6
            // ===============================
            // Table 12
            // ==========

            //for (int i = 1; i <= 12; i++)
            //{
            //    Console.WriteLine($"Table {i}");
            //    Console.WriteLine("===========");

            //    for (int j = 1; j <= 20; j++)
            //    {
            //        Console.WriteLine($"{i} * {j} = {i * j}");
            //    }

            //    Console.WriteLine("==================================");
            //}


            // Jump Statements
            // Break // Stop
            // Continue // Skip
            // Go..To



            //for (int i = 1; i <= 4; i++)
            //{
            //    if (i == 3)
            //        break;

            //    Console.Write(i);
            //    Console.WriteLine("\t Tamam Welcome");
            //}



            //for (int i = 1; i <= 4; i++)
            //{
            //    if (i == 3)
            //        continue;

            //    Console.Write(i);
            //    Console.WriteLine("\t Tamam Welcome");
            //}


            //Location: Console.WriteLine("End");

            //    for (int i = 1; i <= 4; i++)
            //    {
            //        if (i == 3)
            //            goto Location;

            //        Console.Write(i);
            //        Console.WriteLine("\t Tamam Welcome");

            //    }




            #endregion

            #region Handle Exceptions

            // Try ... Catch ... Finally 
            // Throw (Custom Exception)

            //try
            //{
            //    Console.Write("First N : ");
            //    int Fn = int.Parse(Console.ReadLine());

            //    Console.Write("Second N : ");
            //    int Sn = int.Parse(Console.ReadLine());

            //    Console.WriteLine($"The Result : {Fn / Sn}");
            //}
            //catch (DivideByZeroException)
            //{
            //    // 3 - Friendly Message + Recomended Solve
            //    Console.WriteLine($"Divid By Zeroooooooo Error , don't divid by zero");
            //}
            //catch (FormatException x)
            //{
            //    // 3 - Friendly Message + Recomended Solve
            //    Console.WriteLine($" {x.Message} , Enter Integer Value");
            //}
            //catch (Exception x)
            //{

            //    // Handle Exception

            //    // 1 -  Static Message
            //    // Console.WriteLine("Error ");

            //    // 2 - Friendly Message 
            //    //Console.WriteLine(x.Message);

            //    // 3 - Friendly Message + Recomended Solve
            //    // Console.WriteLine(x.Message);

            //    // 4 - Friendly Message + Recomended Solve + Try To Solve

            //    // Log Exception

            //    // In Database
            //    // In Server (SeriLog , NLog)
            //    // Event Viewer
            //}
            //finally
            //{
            //    // Console.WriteLine("End OF Program");
            //    // GC.Collect();
            //}


            //try
            //{
            //    int age = 15;

            //    if (age > 18)
            //        Console.WriteLine("Accessed Successfully !");
            //    else
            //        throw new ElgendyException();
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);
            //}


            // Error (At Compile Time)
            // Syntax Error (Compile Time)
            // Run Time Error (Exceptions)
            // Logical Error - (Unit Test)

            // Exceptions (At Run Time)
            // Bug


            // Log over Event Viewer

            //try
            //{
            //    int age = 15;

            //    if (age > 18)
            //        Console.WriteLine("Accessed Successfully !");
            //    else
            //        throw new ArithmeticException("Access Denied");
            //}
            //catch (Exception ex)
            //{

            //    EventLog log = new EventLog();

            //    log.Source = "Hr System";
            //    log.WriteEntry(ex.Message, EventLogEntryType.Error);
            //}

            #endregion

            #region Array

            // Array ==> Multi Value In One Variable , With The Same DataType
            // Array ==> Reference Type , Heap Memory
            // Array ==> Fixed Size , Fixed Type

            // Array Types ===> Single Dimentional , Multi Dimentional , Jagged Array


            //int[] x = new int[3];

            //int[] dest = new int[2];

            //x[0] = 10;
            //x[1] = 20;
            //x[2] = 30;


            //foreach (var item in x)
            //{
            //    Console.WriteLine(item);
            //}

            //for (int i = 0; i < x.Length; i++)
            //{
            //    Console.WriteLine(x[i]);
            //}

            //for (int i = 0; i < x.Length; i++)
            //{
            //    x[i] = int.Parse(Console.ReadLine());
            //}

            //Console.WriteLine("=========================");

            //Array.Sort(x);
            //Array.Reverse(x);
            //Array.Clear(x);
            //Array.Copy(x, 1, dest, 0, 2);

            //foreach (var item in dest)
            //{
            //    Console.WriteLine(item);
            //}


            #endregion


            #region List

            // List ==> Collection Of Data
            // List ==> Reference Type , Heap Memory
            // List ==> Fixed Type , Dynamic Length

            // <> ==> Generic
            // List<int> numbers = new List<int>() { 10, 30, 30 };

            //numbers.Add(10);
            //numbers.Add(20);
            //numbers.Add(30);

            //numbers.Remove(20);
            //foreach (var item in numbers)
            //{
            //    Console.WriteLine(item);
            //}


            //var names = new List<string>() { "Ahmed", "Ali", "Sara" };

            //foreach (var item in names)
            //{
            //    Console.WriteLine(item);
            //}


            //var emp1 = new Employee() { Id = 1, Name = "Ahmed", Salary = 2000 };
            //var emp2 = new Employee() { Id = 2, Name = "Ali", Salary = 3000 };
            //var emp3 = new Employee() { Id = 3, Name = "Sara", Salary = 4000 };

            //var emps = new List<Employee>() { emp1, emp2, emp3 };


            //Console.WriteLine(emps.Count);

            //foreach (var item in emps)
            //{
            //    Console.WriteLine($"{item.Id} - {item.Name} - {item.Salary}");
            //}


            //Employee[] emps = new Employee[3] { emp1, emp2, emp3 };

            //Console.WriteLine(emps[1].Name);

            //foreach (var item in emps)
            //{
            //    Console.WriteLine($"{item.Id} - {item.Name} - {item.Salary}");
            //}

            #endregion



        }
    }
}
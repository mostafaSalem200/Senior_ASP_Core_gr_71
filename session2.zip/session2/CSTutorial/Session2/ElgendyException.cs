﻿namespace Session2
{
    internal class ElgendyException : Exception
    {
        public override string Message => "Elgendy Exception Here";
    }
}

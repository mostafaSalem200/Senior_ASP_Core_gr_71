﻿//using x = System;

namespace Session1
{
    internal class Program
    {

        //readonly int x = 10;

        // Constructor (ctor)

        // Public
        // No Return Type
        // Function The Same Class Name


        //public Program()
        //{
        //    x = 20;
        //}


        // Start Up Point
        static void Main(string[] args)
        {

            #region Intro. To C#

            //Console.BackgroundColor = ConsoleColor.Red;
            //Console.ForegroundColor = ConsoleColor.Black;

            //Console.WriteLine("Welcome In C#");

            //Console.WindowWidth = 40;
            //Console.WindowHeight = 20;

            //Console.WriteLine("");

            // Tips On C#

            // 1 - C# case senstive
            // 2 - (;) must be end of the line
            // 3 - C# Strong Type
            // 4 - C# Recomend "Bascal Case"


            //Console.WriteLine("Current Line");
            //Console.Write("Current Line");
            //Console.Write("Next Line");

            //Console.Write("Plz Enter Your Name : ");
            //var name = Console.ReadLine();
            //var name2 = "samir";
            //Console.WriteLine("Welcome Mr : " + name);
            //Console.WriteLine("Welcome Mr : {0} {1}", name, name2);
            //Console.WriteLine($"Welcome Mr : {name}");


            //Console.Write("Please Enter Your Name : ");
            //var name = Console.ReadLine();

            //Console.Write("Please Enter Your Salary : ");
            //var salary = int.Parse(Console.ReadLine()); // C# Casting
            ////var salary = Convert.ToInt32(Console.ReadLine()); // .Net Casting
            //// int      Int32


            //Console.WriteLine($"Welcome Mr : {name} , Your Salary Is : {salary + 1000}");

            /*
             * 
             * 
             * 
             * 
             * 
             * 
             * 
             * 
             * 
             */


            #endregion


            #region C# Data Types

            // Run Time 
            // Compile Time


            // Predefined DataTypes (Primitive DataTypes) - Built In DataTypes

            // byte   -   short   -   int   -  long  (Integer Data)
            //byte x = 0;
            //int y = 20;

            //Console.WriteLine(sizeof(double));
            //Console.WriteLine(sizeof(float));
            //Console.WriteLine(sizeof(decimal));

            //Console.WriteLine($"From : {byte.MinValue} - To : {byte.MaxValue} ");

            // float   -   decimal    -   double  (Fraction Data)

            //double x = 2.6;
            //double y = 5;

            //float z = 6.2f;
            //decimal w = 6.2m;

            // bool - (True/False Data)

            //bool a = true;
            //bool b = false;


            // char - (To Store Only one character)

            //char x = 'a';

            // string - ( To store more than one character)

            //string fullName = "Ahmed Samir";
            //Console.WriteLine("\"These two semi colons are removed when i am printed\"");
            //Console.WriteLine("Ahmed \t\t\t Samir");

            //string path = @"D:\Rounds\Senior\HTI\
            //                BackEnd\C#\
            //                Session_1";


            //// var
            //var x = 10;  // No Need To Casting , Value Type , Stack
            //var t ;

            //// object
            //object y = 10; // Need To Casting , Reference Type , Heap 
            //object o;

            //// dynamic
            //dynamic z = "Ahmed"; // No Need To Casting , Reference Type , Heap
            //dynamic p;



            // User Defined DataTypes (Non Primitive DataTypes) 

            // Class
            // Struct
            // Enum
            // Interface
            // Array
            // String
            // DateTime



            // Signed & unSigned



            //int x = -1; // Signed
            //uint y = -1; // unSigned
            //ushort z = -2; // unSigned
            //ulong w = -3; // unSigned

            //byte a = -1;  // unSigned
            //sbyte b = -2; // Signed



            //object a = default;
            //object a = "";
            //object a = null;

            //Console.WriteLine(a);



            //DateTime x = DateTime.Now;
            //string x = DateTime.Now.ToShortDateString();
            //var x = DateTime.Now.Year;

            //Console.WriteLine(x);



            //Console.Write("Enter Your Name : ");
            //var name = Console.ReadLine();

            //Console.Write("Enter Your Birthdate : ");
            //var birthDate = DateTime.Parse(Console.ReadLine());


            //var age = DateTime.Now.Year - birthDate.Year;

            //Console.WriteLine($"Welcome {name} , Your Age Is {age}");





            #endregion


            #region C# Variables


            // Rules To Declare Variable

            // int 1th = 10; // Can not start with numbers
            // int %x = 10; // Can not Start With Special Characters Except (_)
            // int unsafe = 10; // Can not Name (Reserved Word)
            // string First Name = "Ahmed"; // Can not Contain spaces


            // How To Write C#

            //// Camel Case
            //string firstName = "";

            //// Bascal Case
            //string FirstName = "";

            //// Hungarian Notation
            //string strFirstName = "";



            // Variable  ==> Store For Data , His Value Not Static

            //int x = 10;
            //x = 20;
            //x = 30;


            // Constant ==> Store For Data , But his value static
            //const int x = 10;
            //x = 20;


            // Read Only

            // Define over a class



            #endregion


            #region Casting

            // Casting ==> Is A Way that told the compiler "do this, i know what i'm doing"


            // Implicit

            //byte x = 10;
            //int y = x;
            //Console.WriteLine(y);


            //string FirstName = Console.ReadLine();
            //Console.WriteLine(FirstName);




            // Explicit - Need To Cast

            // Memory Casting
            //checked
            //{
            //    int x = int.Parse(Console.ReadLine());
            //    byte y = (byte)x;
            //    Console.WriteLine(y);
            //}



            // Type Casting
            //int salary = int.Parse(Console.ReadLine());



            #endregion

        }
    }
}